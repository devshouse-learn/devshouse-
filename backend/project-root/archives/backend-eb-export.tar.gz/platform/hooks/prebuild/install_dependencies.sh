#!/bin/bash
# Install Node.js dependencies before build
cd /var/app/staging
npm install --production
